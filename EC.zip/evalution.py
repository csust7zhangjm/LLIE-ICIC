import os
import time

from skimage.metrics import structural_similarity as compare_ssim
from skimage.metrics import peak_signal_noise_ratio as compare_psnr

from skimage.metrics import mean_squared_error as mse
import numpy as np
import torch
from IQA_pytorch import SSIM, MS_SSIM

import argparse
import data_load

from tqdm import tqdm

parser = argparse.ArgumentParser(description='PyTorch Low-Light Enhancement')
parser.add_argument('--gpus', default=0, type=int, help='number of gpu')
# parser.add_argument('--test_LL_folder', default="D:\study\code\datasets\LOL\eval15\Low")
# parser.add_argument('--test_NL_folder', default="D:\study\code\datasets\LOL\eval15\High")


opt = parser.parse_args()
print(opt)


def checkpoint(model, epoch, opt):
    try:
        os.stat(opt.save_folder)
    except:
        os.mkdir(opt.save_folder)

    model_out_path = opt.save_folder + "{}_{}.pth".format(Name_Exp, epoch)
    torch.save(model.state_dict(), model_out_path)

    print("Checkpoint saved to {}".format(model_out_path))
    return model_out_path

def eval_train(low,gt):
    low_img = low.cpu().detach().numpy()
    high_img = gt.cpu().detach().numpy()
    sum_psnr = 0
    sum_ssim = 0
    sum_mse = 0


    for i in range(low_img.shape[0]):
        ll = low_img[i]
        hh = high_img[i]

        # (400,600,3)
        low_im = np.transpose(ll,(1,2,0))
        high_im = np.transpose(hh,(1,2,0))

        #===psnr和ssim的计算
        psnr_val = compare_psnr(hh, ll) #(true,test)
        ssim_val = compare_ssim(low_im, high_im, multichannel=True)

        #评价指标
        mse_val = mse(hh, ll)

        sum_psnr += psnr_val
        sum_ssim += ssim_val
        sum_mse += mse_val


    avg_psnr = sum_psnr / len(low_img)
    avg_ssim = sum_ssim / len(low_img)
    avg_mse = sum_mse / len(low_img)

    return avg_psnr,avg_ssim,avg_mse
# from .iatmodel.utils import validation
def eval_test(model1,model):
    # 读取数据集
    img = data_load.load_init_test()

    sum_psnr = 0
    sum_ssim = 0
    sum_niqe = 0
    sum_mse = 0
    sum_mae = 0

    for iteration, imgs in tqdm(enumerate(img)):
        with torch.no_grad():
            low_img, high_img, att_img= imgs[0].cuda(), imgs[1].cuda(), imgs[2].cuda()
            start = time.time()
            van = model1(low_img,att_img)
            output = model(low_img,van,high_img)
            end = time.time()
            time_sum = end - start
            print('infer_time:', time_sum)

            enhanced_img = output["pred_x"]
            # ssim = SSIM(enhanced_img, high_img).item()
            # psnr = PSNR(enhanced_img, high_img).item()
            psnr, ssim, mse = eval_train(enhanced_img, high_img)

            sum_psnr += psnr
            sum_ssim += ssim
            # sum_niqe += niqe_val
            # sum_mse += mse
            # sum_mae += mae_val
            # print("PSNR :{} SSIM:{} NIQE:{} MSE:{}".format(psnr, ssim,niqe_val,mse))

    avg_psnr = sum_psnr / (iteration+1)
    avg_ssim = sum_ssim / (iteration+1)
    avg_niqe = sum_niqe / (iteration+1)
    # avg_niqe = 0
    avg_mse = sum_mse / (iteration+1)
    # avg_mae = sum_mae / (iteration+1)
    # print("AVG PSNR:{} AVG SSIM:{} AVG NIQR:{} AVG MSE:{}".format(avg_psnr,avg_ssim,avg_niqe,avg_mse))
    return avg_psnr,avg_ssim,avg_niqe,avg_mse
from model.IAMEN import IAMEN
from model.wavelet import Fusion_Ch_H
if __name__ == "__main__":
    #cfg()
    cuda = opt.gpus
    print("test cuda:",cuda)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(opt.gpus)
    # =============================#
    #          Build model        #
    # =============================#
    print('===> Build model')
    model1 = IAMEN().cuda()
    model = Fusion_Ch_H().cuda()

    print('---------- Networks architecture -------------')
    print(model)
    print('----------------------------------------------')

    best_psnr = 0.
    best_epoch = 0
    psnr_score = 0.

    model1.load_state_dict(torch.load("IAMEN/lcdp_IAMEN/van100.pth")) #MSEC best epoch
    model.load_state_dict(torch.load("checkpoints/lcdp/best_EpochP.pth")) #MSEC best epoch

    model.eval()
    psnr_score, ssim_score, niqe_score, mse_score = eval_test(model1,model)

    print("AVG PSNR:{} AVG SSIM:{} AVG NIQE:{} AVG MSE:{}" .format(psnr_score, ssim_score, niqe_score, mse_score))
