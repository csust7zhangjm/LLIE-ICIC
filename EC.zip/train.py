import data_load
import os
import torch.optim
import argparse
import torch.nn as nn
from model.IAMEN import IAMEN
from lib.utils import TVLoss,Colorloss,PerceptualLoss,MS_SSIMLoss
from model.wavelet import Fusion_Ch_H


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu_id', type=str, default=0)
    parser.add_argument("--normalize", action="store_false", help="Default Normalize in LCDP training.")
    parser.add_argument('--train_LL_folder', type=str, default="D:/study/code/datasets/")
    parser.add_argument('--img_val_path', type=str, default="D:/study/code/datasets/")
    parser.add_argument('--batch_size', type=int, default=2)
    parser.add_argument('--lr', type=float, default=0.0001) #
    parser.add_argument('--milestones', type=str, default='30,40,120')
    parser.add_argument('--gamma', type=float, default=0.1)
    parser.add_argument('--weight_decay', type=float, default=0.0005)
    parser.add_argument('--pretrain_dir', type=str, default="./IAMEN/lcdp_IAMEN/van100.pth")
    parser.add_argument('--num_epochs', type=int, default=200)
    parser.add_argument('--display_iter', type=int, default=1)
    parser.add_argument('--snapshots_folder', type=str, default="./checkpoints/")
    parser.add_argument('--resize', default=True)
    config = parser.parse_args()

    torch.autograd.set_detect_anomaly(True)

    print(config)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(config.gpu_id)
    ssim_high = 0
    psnr_high = 0
    if not os.path.exists(config.snapshots_folder):
        os.makedirs(config.snapshots_folder)

    #========== Model Setting
    model1 = IAMEN().cuda()
    model = Fusion_Ch_H().cuda()

    # ========== Data Setting
    img, val_img = data_load.load_init(config)

    # ========== Model loading and validation
    if config.pretrain_dir is not None:
        model1.load_state_dict(torch.load(config.pretrain_dir))# 预加载模型

    # =============================#
    #         Loss function        #
    # =============================#

    L1_loss = nn.L1Loss()
    p_loss = PerceptualLoss()
    L2_loss = torch.nn.MSELoss()
    TV_loss = TVLoss()

    #设置学习率策略
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config.milestones.split(',')], gamma=config.gamma)
    device = next(model.parameters()).device
    print('the device is:', device)

    model.train()
    print('######## Start IAT Training #########')
    for epoch in range(config.num_epochs):
        print('=============the epoch is:', epoch)

        for iteration, imgs in enumerate(img):
            low_img, high_img= imgs[0].cuda(), imgs[1].cuda()
            #清除梯度
            optimizer.zero_grad()
            model1.train()

            att_re = model1(low_img)
            output = model(low_img,att_re.detach(), high_img) #

            en_input_high0, en_input_high1, pred_LL, enhanced_img = output["input_high0"], output["input_high1"], \
                                                           output["pred_LL"], output["pred_x"]
            gt_high0, gt_high1, gt_LL = output["gt_high0"], output["gt_high1"], output["gt_LL"]


            #=======================================#
            #==============   LOSS   ===============#
            #=======================================#
            fr_loss = L2_loss(en_input_high0, gt_high0) + L2_loss(en_input_high1, gt_high1) + L2_loss(pred_LL, gt_LL)
            loss = L1_loss(enhanced_img,high_img) + 0.5 * p_loss(enhanced_img,high_img) + 0.1 * fr_loss

            # ======= Loss print
            print("Epoch:{},iteration:{} Loss:{}".format(epoch, iteration, loss))

            # 梯度更新
            loss.backward()
            optimizer.step()

        model.eval()
        if ((epoch+1) % 10 == 0):
        # Save Model
            torch.save(model.state_dict(), os.path.join(config.snapshots_folder, str(epoch+1) + '.pth'))

        #更新学习率
        scheduler.step()


