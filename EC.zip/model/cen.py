import torch
import torch.nn as nn
import torch.nn.functional as F


class CEN(nn.Module):
    def __init__(self):
        super(CEN, self).__init__()
        self.inchannel = 3
        self.channel = 32

        self.e1 = ResUnit(self.channel)
        self.e2 = ResUnit(self.channel * 2)
        self.e3 = ResUnit(self.channel * 4)

        # self.ed1 = ResUnit(channel * 2)
        # self.ed2 = ResUnit(channel * 1)
        # self.ed3 = ResUnit(int(channel * 0.5))

        self.fd1 = ResUnit(self.channel * 2)
        self.fd2 = ResUnit(self.channel * 1)
        self.fd3 = ResUnit(int(self.channel * 0.5))

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.conv_in = nn.Conv2d(self.inchannel, self.channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_eout = nn.Conv2d(int(0.5 * self.channel), 3, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_fout = nn.Conv2d(int(0.5 * channel), 1, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1te2 = nn.Conv2d(self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2te3 = nn.Conv2d(2 * self.channel, 4 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1_a = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2_a = nn.Conv2d(2 * self.channel, self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e3_a = nn.Conv2d(4 * self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_fd1td2 = nn.Conv2d(2 * self.channel, 1 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_fd2td3 = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)

        # self.conv_ed1td2 = nn.Conv2d(2 * channel, 1 * channel, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_ed2td3 = nn.Conv2d(channel, int(0.5 * channel), kernel_size=1, stride=1, padding=0, bias=False)

    def _upsample(self, x, y):
        _, _, H, W = y.size()
        return F.upsample(x, size=(H, W), mode='bilinear')

    def forward(self, x, p):
        # x_in = self.conv_in(torch.cat((x, p), dim=1))
        x_in = self.conv_in(x)

        e1 = self.e1(x_in,p)
        p2 = self.maxpool(p)
        e2 = self.e2(self.conv_e1te2(self.maxpool(e1)),p2)
        p3 = self.maxpool(p2)
        e3 = self.e3(self.conv_e2te3(self.maxpool(e2)),p3)

        e1_a = self.conv_e1_a(e1)
        e2_a = self.conv_e2_a(e2)
        e3_a = self.conv_e3_a(e3)

        fd1 = self.fd1(e3_a,p3)
        fd2 = self.fd2((self.conv_fd1td2(self._upsample(fd1, e2)) + e2_a),p2)
        fd3 = self.fd3((self.conv_fd2td3(self._upsample(fd2, e1)) + e1_a),p)

        # ed1 = self.ed1(e3_a + fd1)
        # ed2 = self.ed2(self.conv_ed1td2(self._upsample(ed1, e2)) + fd2 + e2_a)
        # ed3 = self.ed3(self.conv_ed2td3(self._upsample(ed2, e1)) + fd3 + e1_a)

        # x_fout = self.conv_fout(fd3) # to GEM
        x_eout = self.conv_eout(fd3)

        # return x_fout, x_eout, ed1, ed2, ed3, fd1, fd2, fd3, e1, e2, e3
        return x_eout

class CEN_no_att(nn.Module):
    def __init__(self):
        super(CEN_no_att, self).__init__()
        self.inchannel = 3
        self.channel = 32

        self.e1 = ResUnit_no_att(self.channel)
        self.e2 = ResUnit_no_att(self.channel * 2)
        self.e3 = ResUnit_no_att(self.channel * 4)

        # self.ed1 = ResUnit(channel * 2)
        # self.ed2 = ResUnit(channel * 1)
        # self.ed3 = ResUnit(int(channel * 0.5))

        self.fd1 = ResUnit_no_att(self.channel * 2)
        self.fd2 = ResUnit_no_att(self.channel * 1)
        self.fd3 = ResUnit_no_att(int(self.channel * 0.5))

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.conv_in = nn.Conv2d(self.inchannel, self.channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_eout = nn.Conv2d(int(0.5 * self.channel), 3, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_fout = nn.Conv2d(int(0.5 * channel), 1, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1te2 = nn.Conv2d(self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2te3 = nn.Conv2d(2 * self.channel, 4 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1_a = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2_a = nn.Conv2d(2 * self.channel, self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e3_a = nn.Conv2d(4 * self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_fd1td2 = nn.Conv2d(2 * self.channel, 1 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_fd2td3 = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)

        # self.conv_ed1td2 = nn.Conv2d(2 * channel, 1 * channel, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_ed2td3 = nn.Conv2d(channel, int(0.5 * channel), kernel_size=1, stride=1, padding=0, bias=False)

    def _upsample(self, x, y):
        _, _, H, W = y.size()
        return F.upsample(x, size=(H, W), mode='bilinear')

    def forward(self, x):
        # x_in = self.conv_in(torch.cat((x, p), dim=1))
        x_in = self.conv_in(x)

        e1 = self.e1(x_in)
        # p2 = self.maxpool(p)
        e2 = self.e2(self.conv_e1te2(self.maxpool(e1)))
        # p3 = self.maxpool(p2)
        e3 = self.e3(self.conv_e2te3(self.maxpool(e2)))

        e1_a = self.conv_e1_a(e1)
        e2_a = self.conv_e2_a(e2)
        e3_a = self.conv_e3_a(e3)

        fd1 = self.fd1(e3_a)
        fd2 = self.fd2((self.conv_fd1td2(self._upsample(fd1, e2)) + e2_a))
        fd3 = self.fd3((self.conv_fd2td3(self._upsample(fd2, e1)) + e1_a))

        # ed1 = self.ed1(e3_a + fd1)
        # ed2 = self.ed2(self.conv_ed1td2(self._upsample(ed1, e2)) + fd2 + e2_a)
        # ed3 = self.ed3(self.conv_ed2td3(self._upsample(ed2, e1)) + fd3 + e1_a)

        # x_fout = self.conv_fout(fd3) # to GEM
        x_eout = self.conv_eout(fd3)

        # return x_fout, x_eout, ed1, ed2, ed3, fd1, fd2, fd3, e1, e2, e3
        return x_eout

class CEN_half(nn.Module):
    def __init__(self):
        super(CEN_half, self).__init__()
        self.inchannel = 3
        self.channel = 32

        self.e1 = ResUnit(self.channel)
        self.e2 = ResUnit(self.channel * 2)
        self.e3 = ResUnit(self.channel * 4)

        # self.ed1 = ResUnit(channel * 2)
        # self.ed2 = ResUnit(channel * 1)
        # self.ed3 = ResUnit(int(channel * 0.5))

        self.fd1 = ResUnit_no_att(self.channel * 2)
        self.fd2 = ResUnit_no_att(self.channel * 1)
        self.fd3 = ResUnit_no_att(int(self.channel * 0.5))

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.conv_in = nn.Conv2d(self.inchannel, self.channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_eout = nn.Conv2d(int(0.5 * self.channel), 3, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_fout = nn.Conv2d(int(0.5 * channel), 1, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1te2 = nn.Conv2d(self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2te3 = nn.Conv2d(2 * self.channel, 4 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1_a = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2_a = nn.Conv2d(2 * self.channel, self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e3_a = nn.Conv2d(4 * self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_fd1td2 = nn.Conv2d(2 * self.channel, 1 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_fd2td3 = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)

        # self.conv_ed1td2 = nn.Conv2d(2 * channel, 1 * channel, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_ed2td3 = nn.Conv2d(channel, int(0.5 * channel), kernel_size=1, stride=1, padding=0, bias=False)

    def _upsample(self, x, y):
        _, _, H, W = y.size()
        return F.upsample(x, size=(H, W), mode='bilinear')

    def forward(self, x, p):
        # x_in = self.conv_in(torch.cat((x, p), dim=1))
        x_in = self.conv_in(x)

        e1 = self.e1(x_in, p)
        p2 = self.maxpool(p)
        e2 = self.e2(self.conv_e1te2(self.maxpool(e1)), p2)
        p3 = self.maxpool(p2)
        e3 = self.e3(self.conv_e2te3(self.maxpool(e2)), p3)

        e1_a = self.conv_e1_a(e1)
        e2_a = self.conv_e2_a(e2)
        e3_a = self.conv_e3_a(e3)

        fd1 = self.fd1(e3_a)
        fd2 = self.fd2((self.conv_fd1td2(self._upsample(fd1, e2)) + e2_a))
        fd3 = self.fd3((self.conv_fd2td3(self._upsample(fd2, e1)) + e1_a))

        # ed1 = self.ed1(e3_a + fd1)
        # ed2 = self.ed2(self.conv_ed1td2(self._upsample(ed1, e2)) + fd2 + e2_a)
        # ed3 = self.ed3(self.conv_ed2td3(self._upsample(ed2, e1)) + fd3 + e1_a)

        # x_fout = self.conv_fout(fd3) # to GEM
        x_eout = self.conv_eout(fd3)

        # return x_fout, x_eout, ed1, ed2, ed3, fd1, fd2, fd3, e1, e2, e3
        return x_eout

class CEN_half1(nn.Module):
    def __init__(self):
        super(CEN_half1, self).__init__()
        self.inchannel = 3
        self.channel = 32

        self.e1 = ResUnit_nop(self.channel)
        self.e2 = ResUnit_nop(self.channel * 2)
        self.e3 = ResUnit_nop(self.channel * 4)

        # self.ed1 = ResUnit(channel * 2)
        # self.ed2 = ResUnit(channel * 1)
        # self.ed3 = ResUnit(int(channel * 0.5))

        self.fd1 = ResUnit_no_att(self.channel * 2)
        self.fd2 = ResUnit_no_att(self.channel * 1)
        self.fd3 = ResUnit_no_att(int(self.channel * 0.5))

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.conv_in = nn.Conv2d(self.inchannel, self.channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_eout = nn.Conv2d(int(0.5 * self.channel), 3, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_fout = nn.Conv2d(int(0.5 * channel), 1, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1te2 = nn.Conv2d(self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2te3 = nn.Conv2d(2 * self.channel, 4 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_e1_a = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e2_a = nn.Conv2d(2 * self.channel, self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_e3_a = nn.Conv2d(4 * self.channel, 2 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_fd1td2 = nn.Conv2d(2 * self.channel, 1 * self.channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_fd2td3 = nn.Conv2d(self.channel, int(0.5 * self.channel), kernel_size=1, stride=1, padding=0, bias=False)

        # self.conv_ed1td2 = nn.Conv2d(2 * channel, 1 * channel, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv_ed2td3 = nn.Conv2d(channel, int(0.5 * channel), kernel_size=1, stride=1, padding=0, bias=False)

    def _upsample(self, x, y):
        _, _, H, W = y.size()
        return F.upsample(x, size=(H, W), mode='bilinear')

    def forward(self, x, p):
        # x_in = self.conv_in(torch.cat((x, p), dim=1))
        x_in = self.conv_in(x)

        e1 = self.e1(x_in, p)
        p2 = self.maxpool(p)
        e2 = self.e2(self.conv_e1te2(self.maxpool(e1)), p2)
        p3 = self.maxpool(p2)
        e3 = self.e3(self.conv_e2te3(self.maxpool(e2)), p3)

        e1_a = self.conv_e1_a(e1)
        e2_a = self.conv_e2_a(e2)
        e3_a = self.conv_e3_a(e3)

        fd1 = self.fd1(e3_a)
        fd2 = self.fd2((self.conv_fd1td2(self._upsample(fd1, e2)) + e2_a))
        fd3 = self.fd3((self.conv_fd2td3(self._upsample(fd2, e1)) + e1_a))

        # ed1 = self.ed1(e3_a + fd1)
        # ed2 = self.ed2(self.conv_ed1td2(self._upsample(ed1, e2)) + fd2 + e2_a)
        # ed3 = self.ed3(self.conv_ed2td3(self._upsample(ed2, e1)) + fd3 + e1_a)

        # x_fout = self.conv_fout(fd3) # to GEM
        x_eout = self.conv_eout(fd3)

        # return x_fout, x_eout, ed1, ed2, ed3, fd1, fd2, fd3, e1, e2, e3
        return x_eout

class ChannelAttentionModule(nn.Module):
    def __init__(self, in_channels):
        super(ChannelAttentionModule, self).__init__()
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        """
        :param x: input( BxCxHxW )
        :return: affinity value + x
        """
        B, C, H, W = x.size()
        proj_query = x.view(B, C, -1)
        proj_key = x.view(B, C, -1).permute(0, 2, 1)
        affinity = torch.matmul(proj_query, proj_key)
        affinity_new = torch.max(affinity, -1, keepdim=True)[0].expand_as(affinity) - affinity
        affinity_new = self.softmax(affinity_new)
        proj_value = x.view(B, C, -1)
        weights = torch.matmul(affinity_new, proj_value)
        weights = weights.view(B, C, H, W)
        out = self.gamma * weights + x
        return out


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        # 平均池化
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # 最大池化
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # MLP  除以16是降维系数
        self.fc1 = nn.Conv2d(in_planes, in_planes // 4, 1, bias=False)  # kernel_size=1
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 4, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        # 结果相加
        out = avg_out + max_out
        return self.sigmoid(out)


# 空间注意力
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        # 声明卷积核为 3 或 7
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        # 进行相应的same padding填充
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)  # 平均池化
        max_out, _ = torch.max(x, dim=1, keepdim=True)  # 最大池化
        # 拼接操作
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)  # 7x7卷积填充为3，输入通道为2，输出通道为1
        return self.sigmoid(x)


class ResUnit(nn.Module):
    def __init__(self, channel):
        super(ResUnit, self).__init__()

        self.conv_cam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_sam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_scl_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_cam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_cam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_scl_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_11 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_12 = nn.Conv2d(2 * channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_13 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.act = nn.PReLU(channel)

        self.scl_att = StandardConvolutionalLayers(channel+3,channel)
        self.scl = StandardConvolutionalLayers(channel,channel)
        self.cam = ChannelAttention(channel)
        # self.sam = SpatialAttention()
        # self.cam = ChannelAttentionModule(channel)
        # self.sam = ChannelAttentionModule(channel)#SpatialAttentionModule(channel)
        self.norm = nn.GroupNorm(num_channels=channel, num_groups=1)  # nn.InstanceNorm2d(channel)#

    def forward(self, x, p):
        # x_cam_1 = self.conv_cam_1(x)
        # ScCAM
        x_sam_1 = self.conv_sam_1(x)
        x_scl_1 = self.conv_scl_1(x)

        # x_cam_2 = self.conv_cam_m3(x_cam_1) * self.cam(x_cam_1)
        # x_sam_2 = self.conv_sam_m3(x_sam_1) * self.sam(x_sam_1)

        # 加 attention map
        x_sam_2 = self.scl_att(torch.cat((x_sam_1, p), 1))
        x_scl_2 = self.scl_att(torch.cat((x_scl_1, (1.-p)), 1))

        # x_cam_3 = self.conv_cam_3(x_cam_2)
        x_sam_3 = self.scl(x_sam_2)
        # x_sam_3 = self.conv_sam_3(x_sam_2)
        # x_scl_3 = self.conv_scl_3(x_scl_2)
        x_scl_3 = self.scl(x_scl_2)

        # x_1 = self.conv_11(x_cam_3+x_sam_3)
        x_2 = self.conv_12(torch.cat((x_sam_3, x_scl_3), 1))

        # channel attention
        x_2_ = self.conv_cam_m3(x_2) * self.cam(x_2)

        x_out = self.conv_13(x_2_) + x

        return x_out

class ResUnit_no_att(nn.Module):
    def __init__(self, channel):
        super(ResUnit_no_att, self).__init__()

        self.conv_cam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_sam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_scl_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_cam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_cam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_scl_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_11 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_12 = nn.Conv2d(2 * channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_13 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.act = nn.PReLU(channel)

        # self.scl_att = StandardConvolutionalLayers(channel+3,channel)
        self.scl = StandardConvolutionalLayers(channel,channel)
        self.cam = ChannelAttention(channel)
        # self.sam = SpatialAttention()
        # self.cam = ChannelAttentionModule(channel)
        # self.sam = ChannelAttentionModule(channel)#SpatialAttentionModule(channel)
        self.norm = nn.GroupNorm(num_channels=channel, num_groups=1)  # nn.InstanceNorm2d(channel)#

    def forward(self, x):
        # x_cam_1 = self.conv_cam_1(x)
        # ScCAM
        x_sam_1 = self.conv_sam_1(x)
        x_scl_1 = self.conv_scl_1(x)

        x_sam_2 = self.scl(x_sam_1)
        x_scl_2 = self.scl(x_scl_1)

        # 加 attention map
        # x_sam_2 = self.scl_att(torch.cat((x_sam_1, p), 1))
        # x_scl_2 = self.scl_att(torch.cat((x_scl_1, (1.-p)), 1))

        # x_cam_3 = self.conv_cam_3(x_cam_2)
        x_sam_3 = self.scl(x_sam_2)
        # x_sam_3 = self.conv_sam_3(x_sam_2)
        # x_scl_3 = self.conv_scl_3(x_scl_2)
        x_scl_3 = self.scl(x_scl_2)

        # x_1 = self.conv_11(x_cam_3+x_sam_3)
        x_2 = self.conv_12(torch.cat((x_sam_3, x_scl_3), 1))

        # channel attention
        x_2_ = self.conv_cam_m3(x_2) * self.cam(x_2)

        x_out = self.conv_13(x_2_) + x

        return x_out

class ResUnit_nop(nn.Module):
    def __init__(self, channel):
        super(ResUnit_nop, self).__init__()

        self.conv_cam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_sam_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_scl_1 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.conv_cam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_m3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_cam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_sam_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_scl_3 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.conv_11 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_12 = nn.Conv2d(2 * channel, channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_13 = nn.Conv2d(channel, channel, kernel_size=1, stride=1, padding=0, bias=False)

        self.act = nn.PReLU(channel)

        self.scl_att = StandardConvolutionalLayers(channel+1,channel)
        self.scl = StandardConvolutionalLayers(channel,channel)
        self.cam = ChannelAttention(channel)
        # self.sam = SpatialAttention()
        # self.cam = ChannelAttentionModule(channel)
        # self.sam = ChannelAttentionModule(channel)#SpatialAttentionModule(channel)
        self.norm = nn.GroupNorm(num_channels=channel, num_groups=1)  # nn.InstanceNorm2d(channel)#

    def forward(self, x, p):
        # x_cam_1 = self.conv_cam_1(x)
        # ScCAM
        x_sam_1 = self.conv_sam_1(x)
        x_scl_1 = self.conv_scl_1(x)

        # x_cam_2 = self.conv_cam_m3(x_cam_1) * self.cam(x_cam_1)
        # x_sam_2 = self.conv_sam_m3(x_sam_1) * self.sam(x_sam_1)

        # 加 attention map
        x_sam_2 = self.scl_att(torch.cat((x_sam_1, p), 1))
        x_scl_2 = self.scl_att(torch.cat((x_scl_1, (1.-p)), 1))

        # x_cam_3 = self.conv_cam_3(x_cam_2)
        x_sam_3 = self.scl(x_sam_2)
        # x_sam_3 = self.conv_sam_3(x_sam_2)
        # x_scl_3 = self.conv_scl_3(x_scl_2)
        x_scl_3 = self.scl(x_scl_2)

        # x_1 = self.conv_11(x_cam_3+x_sam_3)
        x_2 = self.conv_12(torch.cat((x_sam_3, x_scl_3), 1))

        # channel attention
        x_2_ = self.conv_cam_m3(x_2) * self.cam(x_2)

        x_out = self.conv_13(x_2_) + x

        return x_out


class StandardConvolutionalLayers(nn.Module):  # StandardConvolutional
    def __init__(self, inchannel,channel):
        super(StandardConvolutionalLayers, self).__init__()

        self.conv_1 = nn.Conv2d(inchannel, channel, kernel_size=3, stride=1, padding=1, bias=False)
        # self.conv_2 = nn.Conv2d(inchannel, channel, kernel_size=3, stride=1, padding=1, bias=False)

        self.act = nn.PReLU(channel)
        self.norm = nn.GroupNorm(num_channels=channel, num_groups=1)  # nn.InstanceNorm2d(channel)#

    def forward(self, x):
        x_1 = self.act(self.norm(self.conv_1(x)))
        # x_2 = self.act(self.norm(self.conv_2(x_1)))

        return x_1


import os
if __name__ == "__main__":
    # -----测试网络结构
    os.environ['CUDA_VISIBLE_DEVICES']='0'
    img = torch.Tensor(1, 3, 400, 600)
    img_gray = torch.Tensor(1,1,400,600)
    img_test =torch.cat((img, img_gray), dim=1)

    net = CEN_no_att().cuda()
    img = net(img.cuda())
    print(net)

    #计算参数量
    print('total parameters:', sum(param.numel() for param in net.parameters()))
    high = net(img)