import torch
import torch.nn as nn
import math
from .cen import CEN,CEN_half
import torchvision

def Normalize(x):
    ymax = 255
    ymin = 0
    xmax = x.max()
    xmin = x.min()
    return (ymax-ymin)*(x-xmin)/(xmax-xmin) + ymin


def dwt_init(x):

    x01 = x[:, :, 0::2, :] / 2
    x02 = x[:, :, 1::2, :] / 2
    x1 = x01[:, :, :, 0::2]
    x2 = x02[:, :, :, 0::2]
    x3 = x01[:, :, :, 1::2]
    x4 = x02[:, :, :, 1::2]
    x_LL = x1 + x2 + x3 + x4  #低频
    x_HL = -x1 - x2 + x3 + x4  #水平高频
    x_LH = -x1 + x2 - x3 + x4  #垂直高频
    x_HH = x1 - x2 - x3 + x4  #对角高频

    return torch.cat((x_LL, x_HL, x_LH, x_HH), 0)


# 使用哈尔 haar 小波变换来实现二维离散小波
def iwt_init(x):
    r = 2
    in_batch, in_channel, in_height, in_width = x.size()
    out_batch, out_channel, out_height, out_width = int(in_batch/(r**2)),in_channel, r * in_height, r * in_width
    x1 = x[0:out_batch, :, :] / 2
    x2 = x[out_batch:out_batch * 2, :, :, :] / 2
    x3 = x[out_batch * 2:out_batch * 3, :, :, :] / 2
    x4 = x[out_batch * 3:out_batch * 4, :, :, :] / 2

    h = torch.zeros([out_batch, out_channel, out_height,
                     out_width]).float().to(x.device)

    h[:, :, 0::2, 0::2] = x1 - x2 - x3 + x4
    h[:, :, 1::2, 0::2] = x1 - x2 + x3 - x4
    h[:, :, 0::2, 1::2] = x1 + x2 - x3 - x4
    h[:, :, 1::2, 1::2] = x1 + x2 + x3 + x4

    return h


class DWT(nn.Module):
    def __init__(self):
        super(DWT, self).__init__()
        self.requires_grad = False  # 信号处理，非卷积运算，不需要进行梯度求导

    def forward(self, x):
        return dwt_init(x)


class IWT(nn.Module):
    def __init__(self):
        super(IWT, self).__init__()
        self.requires_grad = False

    def forward(self, x):
        return iwt_init(x)

def data_transform(X):
    return 2 * X - 1.0


def inverse_data_transform(X):
    return torch.clamp((X + 1.0) / 2.0, 0.0, 1.0)

class Depth_conv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(Depth_conv, self).__init__()
        self.depth_conv = nn.Conv2d(
            in_channels=in_ch,
            out_channels=in_ch,
            kernel_size=(3, 3),
            stride=(1, 1),
            padding=1,
            groups=in_ch
        )
        self.point_conv = nn.Conv2d(
            in_channels=in_ch,
            out_channels=out_ch,
            kernel_size=(1, 1),
            stride=(1, 1),
            padding=0,
            groups=1
        )

    def forward(self, input):
        out = self.depth_conv(input)
        out = self.point_conv(out)
        return out


class Dilated_Resblock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Dilated_Resblock, self).__init__()

        sequence = list()
        sequence += [
            nn.Conv2d(in_channels, out_channels, kernel_size=(3, 3), stride=(1, 1),
                      padding=1, dilation=(1, 1)),
            nn.LeakyReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3, 3), stride=(1, 1),
                      padding=2, dilation=(2, 2)),
            nn.LeakyReLU(),
            nn.Conv2d(out_channels, in_channels, kernel_size=(3, 3), stride=(1, 1),
                      padding=3, dilation=(3, 3)),
            nn.LeakyReLU(),
            nn.Conv2d(out_channels, in_channels, kernel_size=(3, 3), stride=(1, 1),
                      padding=2, dilation=(2, 2)),
            nn.LeakyReLU(),
            nn.Conv2d(out_channels, in_channels, kernel_size=(3, 3), stride=(1, 1),
                      padding=1, dilation=(1, 1))

        ]

        self.model = nn.Sequential(*sequence)

    def forward(self, x):
        out = self.model(x) + x

        return out
class cross_attention(nn.Module):
    def __init__(self, dim, num_heads, dropout=0.):
        super(cross_attention, self).__init__()
        if dim % num_heads != 0:
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (dim, num_heads)
            )
        self.num_heads = num_heads
        self.attention_head_size = int(dim / num_heads)

        self.query = Depth_conv(in_ch=dim, out_ch=dim)
        self.key = Depth_conv(in_ch=dim, out_ch=dim)
        self.value = Depth_conv(in_ch=dim, out_ch=dim)

        self.dropout = nn.Dropout(dropout)

    def transpose_for_scores(self, x):
        '''
        new_x_shape = x.size()[:-1] + (
            self.num_heads,
            self.attention_head_size,
        )
        print(new_x_shape)
        x = x.view(*new_x_shape)
        '''
        return x.permute(0, 2, 1, 3)

    def forward(self, hidden_states, ctx):
        mixed_query_layer = self.query(hidden_states)
        mixed_key_layer = self.key(ctx)
        mixed_value_layer = self.value(ctx)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)

        attention_probs = nn.Softmax(dim=-1)(attention_scores)

        attention_probs = self.dropout(attention_probs)

        ctx_layer = torch.matmul(attention_probs, value_layer)
        ctx_layer = ctx_layer.permute(0, 2, 1, 3).contiguous()

        return ctx_layer

class HFRM(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(HFRM, self).__init__()

        self.conv_head = Depth_conv(in_channels, out_channels)

        self.dilated_block_LH = Dilated_Resblock(out_channels, out_channels)
        self.dilated_block_HL = Dilated_Resblock(out_channels, out_channels)

        self.cross_attention0 = cross_attention(out_channels, num_heads=8)
        self.dilated_block_HH = Dilated_Resblock(out_channels, out_channels)
        self.conv_HH = nn.Conv2d(out_channels*2, out_channels, kernel_size=3, stride=1, padding=1)
        self.cross_attention1 = cross_attention(out_channels, num_heads=8)

        self.conv_tail = Depth_conv(out_channels, in_channels)

    def forward(self, x):

        b, c, h, w = x.shape

        residual = x

        x = self.conv_head(x)

        x_HL, x_LH, x_HH = x[:b//3, ...], x[b//3:2*b//3, ...], x[2*b//3:, ...]

        x_HH_LH = self.cross_attention0(x_LH, x_HH)
        x_HH_HL = self.cross_attention1(x_HL, x_HH)

        x_HL = self.dilated_block_HL(x_HL)
        x_LH = self.dilated_block_LH(x_LH)

        x_HH = self.dilated_block_HH(self.conv_HH(torch.cat((x_HH_LH, x_HH_HL), dim=1)))

        out = self.conv_tail(torch.cat((x_HL, x_LH, x_HH), dim=0))

        return out + residual

from torchvision.transforms import Grayscale
# 创建一个转换对象
to_gray = Grayscale(num_output_channels=1)

class HFEM(nn.Module):
    def __init__(self):
        super(HFEM, self).__init__()

        # self.args = args
        # self.config = config
        # self.device = config.device

        self.high_enhance0 = HFRM(in_channels=3, out_channels=64)
        self.high_enhance1 = HFRM(in_channels=3, out_channels=64)
        # self.Unet = DiffusionUNet(config)

        # betas = get_beta_schedule(
        #     beta_schedule=config.diffusion.beta_schedule,
        #     beta_start=config.diffusion.beta_start,
        #     beta_end=config.diffusion.beta_end,
        #     num_diffusion_timesteps=config.diffusion.num_diffusion_timesteps,
        # )

        # self.betas = torch.from_numpy(betas).float()
        # self.num_timesteps = self.betas.shape[0]

    # @staticmethod
    # def compute_alpha(beta, t):
    #     beta = torch.cat([torch.zeros(1).to(beta.device), beta], dim=0)
    #     a = (1 - beta).cumprod(dim=0).index_select(0, t + 1).view(-1, 1, 1, 1)
    #     return a

    # def sample_training(self, x_cond, b, eta=0.):
    #     skip = self.config.diffusion.num_diffusion_timesteps // self.args.sampling_timesteps
    #     seq = range(0, self.config.diffusion.num_diffusion_timesteps, skip)
    #     n, c, h, w = x_cond.shape
    #     seq_next = [-1] + list(seq[:-1])
    #     x = torch.randn(n, c, h, w, device=self.device)
    #     xs = [x]
    #     for i, j in zip(reversed(seq), reversed(seq_next)):
    #         t = (torch.ones(n) * i).to(x.device)
    #         next_t = (torch.ones(n) * j).to(x.device)
    #         at = self.compute_alpha(b, t.long())
    #         at_next = self.compute_alpha(b, next_t.long())
    #         xt = xs[-1].to(x.device)
    #
    #         et = self.Unet(torch.cat([x_cond, xt], dim=1), t)
    #         x0_t = (xt - et * (1 - at).sqrt()) / at.sqrt()
    #
    #         c1 = eta * ((1 - at / at_next) * (1 - at_next) / (1 - at)).sqrt()
    #         c2 = ((1 - at_next) - c1 ** 2).sqrt()
    #         xt_next = at_next.sqrt() * x0_t + c1 * torch.randn_like(x) + c2 * et
    #         xs.append(xt_next.to(x.device))
    #
    #     return xs[-1]

    def forward(self, x, gt):
        data_dict = {}
        dwt, idwt = DWT(), IWT()

        input_img = x[:, :3, :, :]
        gt_img = gt[:, :3, :, :]
        n, c, h, w = input_img.shape

        input_img_norm = data_transform(input_img)
        gt_img_norm = data_transform(gt_img)

        input_dwt = dwt(input_img_norm)
        gt_dwt = dwt(gt_img_norm)

        # inputLL低频  input_high0 高频部分（水平、垂直、对角）
        input_LL, input_high0 = input_dwt[:n, ...], input_dwt[n:, ...]
        gt_LL, gt_high0 = gt_dwt[:n, ...], gt_dwt[n:, ...]

        # 将图像转换为灰度模式
        # input_high0_gray = to_gray(1.-input_high0)
        # gt_high0_gray = to_gray(1.-gt_high0)
        # torchvision.utils.save_image(input_high0_gray[:1,...], "./data/high/i_v.png")
        # torchvision.utils.save_image(input_high0_gray[1:2, ...], "./data/high/i_h.png")
        # torchvision.utils.save_image(input_high0_gray[2:,...], "./data/high/i_d.png")
        # torchvision.utils.save_image(gt_high0_gray[:1,...], "./data/high/o_v.png")
        # torchvision.utils.save_image(gt_high0_gray[1:2,...], "./data/high/o_h.png")
        # torchvision.utils.save_image(gt_high0_gray[2:,...], "./data/high/o_d.png")

        # high_enhance0 == HFRM 的转换结果
        input_high0 = self.high_enhance0(input_high0)
        # 再dwt一次，作用：多次小波变换可以逐步提取图像的细节信息
        input_LL_dwt = dwt(input_LL)
        input_LL_LL, input_high1 = input_LL_dwt[:n, ...], input_LL_dwt[n:, ...]
        gt_LL_dwt = dwt(gt_LL)
        gt_LL_LL, gt_high1 = gt_LL_dwt[:n, ...], gt_LL_dwt[n:, ...]

        # 将图像转换为灰度模式
        # input_high1_gray = to_gray(1.-input_high1)
        # gt_high1_gray = to_gray(1.-gt_high1)
        # torchvision.utils.save_image(input_high1_gray[:1, ...], "./data/high/ii_v.png")
        # torchvision.utils.save_image(input_high1_gray[1:2, ...], "./data/high/ii_h.png")
        # torchvision.utils.save_image(input_high1_gray[2:, ...], "./data/high/ii_d.png")
        # torchvision.utils.save_image(gt_high1_gray[:1, ...], "./data/high/oo_v.png")
        # torchvision.utils.save_image(gt_high1_gray[1:2, ...], "./data/high/oo_h.png")
        # torchvision.utils.save_image(gt_high1_gray[2:, ...], "./data/high/oo_d.png")

        input_high1 = self.high_enhance1(input_high1)

        # 将图像转换为灰度模式
        # input_high1_gray = to_gray(1.-input_high1)
        # torchvision.utils.save_image(input_high1_gray[:1, ...], "./data/high/e_v.png")
        # torchvision.utils.save_image(input_high1_gray[1:2, ...], "./data/high/e_h.png")
        # torchvision.utils.save_image(input_high1_gray[2:, ...], "./data/high/e_d.png")

        pred_LL = idwt(torch.cat((input_LL_LL, input_high1), dim=0))
        pred_x = idwt(torch.cat((input_LL, input_high0), dim=0))

        pred_x = inverse_data_transform(pred_x)

        data_dict["input_high0"] = input_high0
        data_dict["input_high1"] = input_high1
        data_dict["pred_LL"] = pred_LL
        data_dict["pred_x"] = pred_x
        data_dict["gt_high0"] = gt_high0
        data_dict["gt_high1"] = gt_high1
        data_dict["gt_LL"] = gt_LL

        return data_dict


class Fusion_Ch_H(nn.Module):
    def __init__(self):
        super(Fusion_Ch_H, self).__init__()
        self.cen = CEN_half()
        self.hfem = HFEM()

    def forward(self, x ,y, gt):
        out1 = self.cen(x,y)
        out = self.hfem(out1, gt)
        return out

import os
if __name__ == "__main__":
    # -----测试网络结构
    os.environ['CUDA_VISIBLE_DEVICES']='0'
    img = torch.Tensor(1, 3, 400, 600)
    img_gray = torch.Tensor(1,1,400,600)
    # img_test =torch.cat((img, img_gray), dim=1)

    # net = Fusion_C_H().cuda()
    net = HFEM().cuda()
    # img = net(img.cuda(),gt.cuda())
    print(net)

    #计算参数量
    print('total parameters:', sum(param.numel() for param in net.parameters()))
    high = net(img)