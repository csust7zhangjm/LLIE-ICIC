import torch.nn as nn
import torch
import torch.nn.functional as F

class _Conv_Block(nn.Module):
    def __init__(self):
        super(_Conv_Block, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=False)
        self.in1 = nn.BatchNorm2d(64, affine=True)
        self.relu = nn.LeakyReLU(0.2, inplace=False)
        self.conv2 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=False)
        self.in2 = nn.BatchNorm2d(64, affine=True)

    def forward(self, x):
        identity_data = x
        output = self.relu(self.in1(self.conv1(x)))
        output = self.in2(self.conv2(output))
        return output

class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=False),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y

class SALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel, 1, padding=0, bias=True),
                nn.ReLU(inplace=False), #####LeakyReLU
                nn.Conv2d(channel, 1, 1, padding=0, bias=True),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.conv_du(x)
        return x * y

#SE BLOCK
class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=False),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

class Residual_Block_New(nn.Module):
    def __init__(self, in_num, out_num, dilation_factor):
        super(Residual_Block_New, self).__init__()
        self.conv1 = (nn.Conv2d(in_channels=in_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        self.in1 = nn.BatchNorm2d(out_num)
        self.relu = nn.ReLU(inplace=False)

        self.conv2 = (nn.Conv2d(in_channels=out_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        self.in2 = nn.BatchNorm2d(out_num)
        self.se = SELayer(channel=out_num)

    def forward(self, x):
        identity_data = x
        output = self.relu((self.conv1(x)))
        output = (self.conv2(output))

        #USE SE BLOCK
        se = self.se(output)
        output = se + identity_data
        return output

class Residual_Block_new(nn.Module):
    def __init__(self, in_num, out_num, dilation_factor):
        super(Residual_Block_new, self).__init__()
        self.conv1 = (nn.Conv2d(in_channels=in_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        self.in1 = nn.BatchNorm2d(out_num)
        self.relu = nn.ReLU(inplace=False)
        # 减少一个conv
        # self.conv2 = (nn.Conv2d(in_channels=out_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        # self.in2 = nn.BatchNorm2d(out_num)
        self.se = SELayer(channel=out_num)

    def forward(self, x):
        identity_data = x
        output = self.relu((self.conv1(x)))
        # output = (self.conv2(output))

        #USE SE BLOCK
        se = self.se(output)
        output = se + identity_data
        return output

class Residual_Block_Enhance(nn.Module):
    def __init__(self, in_num, out_num, dilation_factor):
        super(Residual_Block_Enhance, self).__init__()
        self.conv1 = (nn.Conv2d(in_channels=in_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        self.in1 = nn.BatchNorm2d(out_num)
        self.relu = nn.ReLU(inplace=False)

        self.conv2 = (nn.Conv2d(in_channels=out_num, out_channels=out_num, kernel_size=3, stride=1, padding=dilation_factor, dilation=dilation_factor, groups= 1, bias=False))
        self.in2 = nn.BatchNorm2d(out_num)
        self.se = SELayer(channel=out_num)

    def forward(self, x):
        identity_data = x
        output = self.relu((self.conv1(x)))
        output = (self.conv2(output))

        #USE SE BLOCK
        se = self.se(output)
        output = se + identity_data
        return output

class Residual_Block(nn.Module):
    def __init__(self):
        super(Residual_Block, self).__init__()
        self.conv1 = (nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=2, dilation=2, groups=1, bias=False))
        self.in1 = nn.InstanceNorm2d(64, affine=True)
        # self.relu = nn.LeakyReLU(0.2, inplace=True)
        self.relu = nn.ReLU(inplace=False)
        self.conv2 = (nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=2, dilation=2, groups=1, bias=False))
        self.in2 = nn.InstanceNorm2d(64, affine=True)
        self.se = SELayer(channel=64)

    def forward(self, x):
        identity_data = x
        output = self.relu(self.in1(self.conv1(x)))
        output = self.in2(self.conv2(output))
        #USE SE BLOCK
        se = self.se(output)
        output = se + identity_data
        return output

class make_dense(nn.Module):
      def __init__(self, nChannels, growthRate, kernel_size=3):
        super(make_dense, self).__init__()
        self.conv = nn.Conv2d(nChannels, growthRate, kernel_size=kernel_size, padding=(kernel_size-1)//2, bias=False)
      def forward(self, x):
        out = F.relu(self.conv(x))
        out = torch.cat((x, out), 1)
        return out

# Residual dense block (RDB) architecture
class RDB(nn.Module):
      def __init__(self, nChannels=64, nDenselayer=5, growthRate=16):
        super(RDB, self).__init__()
        nChannels_ = nChannels
        modules = []
        for i in range(nDenselayer):
            modules.append(make_dense(nChannels_, growthRate))
            nChannels_ += growthRate
        self.dense_layers = nn.Sequential(*modules)
        self.conv_1x1 = nn.Conv2d(nChannels_, nChannels, kernel_size=1, padding=0, bias=False)
        self.se = SELayer(nChannels)
      def forward(self, x):
        out = self.dense_layers(x)
        out = self.conv_1x1(out)
        out = (out) + x
        return out

class mf_fusion(nn.Module):
    def __init__(self):
        super(mf_fusion, self).__init__()
        self.exchange_out = nn.Conv2d(in_channels=3, out_channels=3, kernel_size=1)

    def forward(self,x,y):
        max_ = torch.maximum(x, y)
        avg_ = (x + y) / 2
        out_ = torch.cat((max_, avg_), dim=3)
        out_ = self.exchange_out(out_)
        return out_

class Conv_LReLU_2(nn.Module):
    """
    Network component
    (Conv + LeakyReLU) × 2
    修改：减少一个
    """
    def __init__(self, in_channel, out_channel):
        super(Conv_LReLU_2, self).__init__()
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self.Conv1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, stride=1, padding=1)
        self.Conv2 = nn.Conv2d(out_channel, out_channel, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x = self.lrelu(self.Conv1(x))
        # x = self.lrelu(self.Conv2(x))
        return x

class DBFM_Module(nn.Module):
    """
    This is Dual Branch Fusion Module.
    Input: low light image and lighten image
    Output: RGB
    """

    def __init__(self, ):
        super(DBFM_Module, self).__init__()
        self.up2 = nn.PixelShuffle(2)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self.pool1 = nn.MaxPool2d(kernel_size=2)
        self.mono_conv1 = Conv_LReLU_2(6, 32)
        self.mono_conv2 = Conv_LReLU_2(32, 64)
        self.mono_conv3 = Conv_LReLU_2(64, 128)
        self.mono_conv4 = Conv_LReLU_2(128, 256)
        self.mono_up4 = nn.ConvTranspose2d(256, 128, 2, stride=2)

        self.color_conv1 = Conv_LReLU_2(6, 32)
        self.color_conv2 = Conv_LReLU_2(32, 64)
        self.color_conv3 = Conv_LReLU_2(64, 128)
        self.color_conv4 = Conv_LReLU_2(128, 256)
        self.color_up4 = nn.ConvTranspose2d(256, 128, 2, stride=2)

        self.dual_conv6 = Conv_LReLU_2(256, 256)
        self.dual_up6 = nn.ConvTranspose2d(256, 64, 2, stride=2)
        self.dual_conv7 = Conv_LReLU_2(128, 64)
        self.dual_up7 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.dual_conv8 = Conv_LReLU_2(64, 16)
        self.DBLE_out = nn.Conv2d(16, 3, kernel_size=1, stride=1)

        self.gfuse1 = GFM(256)
        self.gfuse2 = GFM(64)
        self.gfuse3 = GFM(32)


        # self.channel_attention6 = CALayer(256 * 2)
        # self.channel_attention7 = CALayer(192)
        # self.channel_attention8 = CALayer(96)
        # self.channel_attention9 = CALayer(64)
        # 添加池化灰度图层
        # self.pool_g = nn.MaxPool2d(kernel_size=2)

    def forward(self, x, att):
        # 求灰度图
        # x_gray = []
        # i = color.shape[0]
        # for j in range(i):
        #     r, g, b = color[j][0, :, :], color[j][1, :, :], color[j][2, :, :]
        #     x_gray.append((1. - (0.299 * r + 0.587 * g + 0.114 * b)).unsqueeze(0))  # 关注较暗的部分
        # x1_gray_img = torch.stack(x_gray)
        # x2_gray = self.pool_g(x1_gray_img)
        # x3_gray = self.pool_g(x2_gray)

        input_x = torch.cat([x, att], 1)  # 通道维度拼接
        input_y = torch.cat([x, (1-att)], 1)  # 通道维度拼接

        x_conv1 = self.color_conv1(input_x)
        x_pool1 = self.pool1(x_conv1)

        x_conv2 = self.color_conv2(x_pool1)
        x_pool2 = self.pool1(x_conv2)

        x_conv3 = self.color_conv3(x_pool2)
        x_pool3 = self.pool1(x_conv3)

        x_conv4 = self.color_conv4(x_pool3)
        x_up5 = self.color_up4(x_conv4)

        y_conv1 = self.mono_conv1(input_y)
        y_pool1 = self.pool1(y_conv1)

        y_conv2 = self.mono_conv2(y_pool1)
        y_pool2 = self.pool1(y_conv2)

        y_conv3 = self.mono_conv3(y_pool2)
        y_pool3 = self.pool1(y_conv3)

        y_conv4 = self.mono_conv4(y_pool3)
        y_up5 = self.mono_up4(y_conv4)


        # 原通道注意力
        # concat6 = torch.cat([x_up5, y_up5, x_conv3, y_conv3], 1)
        # concat6 = channel_shuffle(concat6,2) #通道shuffle
        # ca6 = self.channel_attention6(concat6)

        # 融合
        x_cat = torch.cat([x_up5, x_conv3], 1)
        y_cat = torch.cat([y_up5, y_conv3], 1)
        fu_1 = self.gfuse1(x_cat, y_cat)
        dual_conv6 = self.dual_conv6(fu_1)
        dual_up6 = self.dual_up6(dual_conv6)

        #融合x,y,再与up6cat
        fu_2 = self.gfuse2(x_conv2,y_conv2)
        concat7 = torch.cat([dual_up6, fu_2], 1)
        # concat7 = channel_shuffle(concat7, 2)  # 通道shuffle
        # ca7 = self.channel_attention7(concat7)
        dual_conv7 = self.dual_conv7(concat7)
        dual_up7 = self.dual_up7(dual_conv7)

        fu_3 = self.gfuse3(x_conv1,y_conv1)
        concat8 = torch.cat([dual_up7, fu_3], 1)
        # concat8 = channel_shuffle(concat8, 2)  # 通道shuffle
        # ca8 = self.channel_attention8(concat8)
        dual_conv8 = self.dual_conv8(concat8)

        DBLE_out = self.lrelu(self.DBLE_out(dual_conv8))

        return DBLE_out

class PDConvFuse(nn.Module):
    def __init__(self, in_channels=None, f_number=None, feature_num=2, bias=True, **kwargs) -> None:
        super().__init__()
        if in_channels is None:
            assert f_number is not None
            in_channels = f_number
        self.feature_num = feature_num
        self.act = nn.GELU()
        self.pwconv = nn.Conv2d(feature_num * in_channels, in_channels, 1, 1, 0, bias=bias)
        self.dwconv = nn.Conv2d(in_channels, in_channels, 3, 1, 1, bias=bias, groups=in_channels, padding_mode='reflect')

    def forward(self, *inp_feats):
        assert len(inp_feats) == self.feature_num
        return self.dwconv(self.act(self.pwconv(torch.cat(inp_feats, dim=1))))

# GATED FUSIO MUDULE
class GFM(nn.Module):
    def __init__(self, in_channels, feature_num=2, bias=True, padding_mode='reflect', **kwargs) -> None:
        super().__init__()
        self.feature_num = feature_num

        hidden_features = in_channels * feature_num
        self.pwconv = nn.Conv2d(hidden_features, hidden_features * 2, 1, 1, 0, bias=bias)
        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, 3, 1, 1, bias=bias, padding_mode=padding_mode, groups=hidden_features * 2)
        self.project_out = nn.Conv2d(hidden_features, in_channels, kernel_size=1, bias=bias)
        self.mlp = nn.Conv2d(in_channels, in_channels, 1, 1, 0, bias=True)

    def forward(self, x, y):
        # assert len(x) == self.feature_num
        # shortcut = x[0]
        out = torch.cat([x, y], dim=1)
        out = self.pwconv(out)
        x1, x2 = self.dwconv(out).chunk(2, dim=1)
        out = F.gelu(x1) * x2
        out = self.project_out(out)
        # return self.mlp(x + shortcut)
        return self.mlp(out)