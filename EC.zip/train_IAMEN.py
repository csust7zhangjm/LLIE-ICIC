import matplotlib.pyplot as plt
import data_load
import os
import torch.optim
import argparse
import torch.nn as nn
from model.IAMEN import IAMEN
from lib.utils import TVLoss,Colorloss,PerceptualLoss,MS_SSIMLoss

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu_id', type=str, default=0)
    parser.add_argument("--normalize", action="store_false", help="Default Normalize in LCDP training.")
    # parser.add_argument('--train_LL_folder', type=str, default="/mnt/dataset/LLIE/SICE/SICEV2/train/input/")
    # parser.add_argument('--img_val_path', type=str, default="/mnt/dataset/LLIE/SICE/SICEV2/test/input/")
    parser.add_argument('--batch_size', type=int, default=2)
    parser.add_argument('--lr', type=float, default=0.001) #
    parser.add_argument('--milestones', type=str, default='10')
    parser.add_argument('--gamma', type=float, default=0.1)
    parser.add_argument('--weight_decay', type=float, default=0.0001)
    parser.add_argument('--pretrain_dir', type=str, default=None)
    parser.add_argument('--num_epochs', type=int, default=20)
    parser.add_argument('--display_iter', type=int, default=1)
    parser.add_argument('--snapshots_folder', type=str, default="/IAMEN/")
    parser.add_argument('--resize', default=True)
    config = parser.parse_args()

    torch.autograd.set_detect_anomaly(True)

    print(config)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(config.gpu_id)
    ssim_high = 0
    psnr_high = 0
    if not os.path.exists(config.snapshots_folder):
        os.makedirs(config.snapshots_folder)

    #========== Model Setting
    model = IAMEN().cuda()

    # ========== Data Setting
    img, val_img = data_load.load_init_att(config)



    L1_loss = nn.L1Loss()
    p_loss = PerceptualLoss()


    #设置学习率策略
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config.milestones.split(',')], gamma=config.gamma)
    device = next(model.parameters()).device
    print('the device is:', device)

    model.train()
    print('######## Start IAT Training #########')
    for epoch in range(config.num_epochs):
        print('=============the epoch is:', epoch)

        for iteration, imgs in enumerate(img):
            low_img, att_map= imgs[0].cuda(), imgs[2].cuda()
            #清除梯度
            optimizer.zero_grad()
            model.train()
            att_re = model(low_img)

            #=======================================#
            #==============   LOSS   ===============#
            #=======================================#

            loss = L1_loss(att_re, att_map) + p_loss(att_re,att_map)


            # ======= Loss print
            print("Epoch:{},iteration:{} Loss:{}".format(epoch, iteration, loss))


            # 梯度更新
            loss.backward()
            optimizer.step()


        model.eval()

        #更新学习率
        scheduler.step()
        if ((epoch+1) % 20 == 0):
        # Save Model
            torch.save(model.state_dict(), os.path.join(config.snapshots_folder, "van"+str(epoch+1) + '.pth'))


