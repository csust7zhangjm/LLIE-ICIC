import os
import cv2
from PIL import Image,ImageFile
import numpy as np
import torchvision
import torch.optim
import glob
import random
import torch.utils.data as data
from torchvision.transforms import Compose, ToTensor, Normalize, ConvertImageDtype
# ImageFile.LOAD_TRUNCATED_IMAGES = True #错误文件跳过
import re

def populate_train_list(limages_path, mode='train'):
    # print(images_path)
    # image_list_lowlight = glob.glob(limages_path + '/*.png')#LOL,lcdp,NPE
    image_list_lowlight = glob.glob(limages_path + '/*.*')#5k,DICM,VV
    # image_list_lowlight = glob.glob(limages_path + '/*.JPG')
    # image_list_lowlight = glob.glob(limages_path + '/*.bmp')#LIME
    train_list = image_list_lowlight

    if mode == 'train':
        random.shuffle(train_list)

    return train_list

#dataloader
class lowlight_loader(data.Dataset):

    def __init__(self, images_path, mode='train', normalize=True,size_correct=True):
        self.train_list = populate_train_list(images_path, mode)
        # self.h, self.w = int(img_size[0]), int(img_size[1])
        # train or test
        self.mode = mode
        self.data_list = self.train_list
        self.normalize = normalize
        # self.size_correct = False
        self.size_correct = size_correct
        print("Total examples:", len(self.train_list))


    def __getitem__(self, index):
        data_lowlight_path = self.data_list[index]

        if self.mode == 'train':
            # 用cv2打开图片
            # data_lowlight = cv2.imread(data_lowlight_path)  # 打开为RGB格式
            # data_lowlight = cv2.cvtColor(data_lowlight, cv2.COLOR_BGR2RGB)
            # data_highlight = cv2.imread(data_lowlight_path.replace('Low', 'High'))
            # data_highlight = cv2.imread(data_lowlight_path.replace('low0', 'normal0').replace('Low', 'Normal'))  # LOLV2
            # data_highlight = cv2.cvtColor(data_highlight, cv2.COLOR_BGR2RGB)
            # data_hsv = cv2.cvtColor(data_lowlight, cv2.COLOR_BGR2HSV)
            #使用PIL
            data_lowlight = Image.open(data_lowlight_path)  # 打开为RGB格式
            # data_highlight = Image.open(data_lowlight_path.replace('Low', 'High').replace('low0', 'high0'))#LOL
            # data_highlight = Image.open(data_lowlight_path.replace('input', 'expertC_gt'))#5k
            # SICE dataset
            # filename= data_lowlight_path.replace('input', 'gt').split('_')
            # data_highlight = Image.open(filename[0]+'.JPG')
            data_highlight = Image.open(data_lowlight_path.replace('input', 'gt'))  #lcdp dataset
            # data_att = Image.open(data_lowlight_path.replace('D:/study/code/datasets/lcdp_dataset/input', './ablation/van'))# get pretrained attention map
            # ======== ME 数据集读取
            # filename= data_lowlight_path.replace('INPUT_IMAGES', 'GT_IMAGES').split('-')
            # data_highlight = Image.open(filename[0]+"-"+filename[1]+".jpg")
            # filepath = data_lowlight_path.replace('input', 'gt')
            # data_highlight = Image.open(re.sub(r'(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg', filepath))
            #======== SID 数据集读取
            # filename= data_lowlight_path.replace('inputimage', 'gtimage').split("_00_")
            # data_highlight = Image.open(filename[0]+".png")
            # data_highlight = Image.open(data_lowlight_path.replace('low','normal').replace('Low','Normal').replace('input','expertC_gt'))


            # 获得attentionmap，计算高亮和低亮之间的差异来创建一个注意力图 train_van
            # Get the image buffer as ndarray
            # buffer1 = np.asarray(data_lowlight).astype(np.int64)
            # buffer2 = np.asarray(data_highlight).astype(np.int64)

            # Subtract data_lowlight from data_highlight
            # attention_map = np.clip(buffer2 - buffer1, 0, 255).astype(np.uint8)

            #图像尺寸调整
            if self.size_correct == True:
                data_lowlight = data_lowlight.resize((512,512), Image.ANTIALIAS)
                data_highlight = data_highlight.resize((512,512), Image.ANTIALIAS)
                # attention_map = Image.fromarray(attention_map)
                # attention_map = attention_map.resize((512,512),Image.ANTIALIAS)

            # train_van
            # data_lowlight, data_highlight,attention_map = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0), (np.asarray(attention_map) / 255.0)
            data_lowlight, data_highlight = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0)

            #正则化
            if self.normalize:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                transform_input = Compose(
                    [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)), ConvertImageDtype(torch.float), ])
                transform_gt = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                # transform_att = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                return transform_input(data_lowlight).permute(2, 0, 1), transform_gt(data_highlight).permute(2, 0, 1)
                # return transform_input(data_lowlight), transform_gt(data_highlight),transform_att(attention_map)
            else:
                # data_lowlight, data_highlight,attention_map = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float(), torch.from_numpy(attention_map).float()
                # return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1), attention_map.permute(2, 0, 1)
                data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1)


        elif self.mode == 'test':
            # 用cv2打开图片
            # data_lowlight = cv2.imread(data_lowlight_path)  # 打开为BGR格式
            # data_lowlight = cv2.cvtColor(data_lowlight, cv2.COLOR_BGR2RGB)#转换 rmal0').replace('Low','Normal'))#LOLV2
            # data_highlight = cv2.cvtColor(data_highlight, cv2.COLOR_BGR2RGB)
            # data_hsv = cv2.cvtColor(data_lowlight, cv2.COLOR_BGR2HSV)

            data_lowlight = Image.open(data_lowlight_path)
            data_highlight = Image.open(data_lowlight_path.replace('input', 'gt'))  #lcdp dataset
            # data_highlight = Image.open(data_lowlight_path.replace('/teval','/teval/gt'))#测试用
            # data_highlight = Image.open(data_lowlight_path)
            # data_highlight = Image.open(data_lowlight_path.replace('test', 'expertC_gt_test'))
            # data_highlight = Image.open(data_lowlight_path.replace('i', 'o'))#x
            # data_highlight = Image.open(data_lowlight_path.replace('low0', 'normal0').replace('Low','Normal')) #LOLv2
            # data_highlight = Image.open(data_lowlight_path.replace('Low', 'High').replace('low', 'high'))  #LOL
            # SICE dataset
            # filename = data_lowlight_path.replace('input', 'gt').split('_')
            # data_highlight = Image.open(filename[0] + '.JPG')
            # data_highlight = Image.open(data_lowlight_path.replace('low', 'gt'))  # sice

            # data_highlight = Image.open(data_lowlight_path.replace('test-input', 'test-gt'))  #lcdp
            # filename = data_lowlight_path.split("\\")[-1]
            # filename = data_lowlight_path.replace('INPUT_IMAGES', 'expert_c_testing_set').split("-")# ME
            # data_highlight = Image.open(filename[0] + ".jpg") # ME
            # data_highlight = Image.open(data_lowlight_path.replace('INPUT_IMAGES', 'expert_c_testing_set'))  # ME
            # filepath = data_lowlight_path.replace('input', 'expert_c_testing_set')
            # data_highlight = Image.open(re.sub(r'(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg', filepath))
            # ======== SID 数据集读取
            # filename = data_lowlight_path.replace('inputimage', 'gtimage').split("_")
            # data_highlight = Image.open(filename[0] + ".png")

            # 获得attentionmap
            # Get the image buffer as ndarray
            buffer1 = np.asarray(data_lowlight).astype(np.int64)
            buffer2 = np.asarray(data_highlight).astype(np.int64)

            # Subtract data_lowlight from data_highlight

            attention_map = np.clip(buffer2 - buffer1, 0, 255).astype(np.uint8)

            if self.size_correct == True:
                # data_lowlight = cv2.resize(data_lowlight, (512, 512))
                # data_highlight = cv2.resize(data_highlight, (512, 512))
                data_lowlight = data_lowlight.resize((512,512), Image.ANTIALIAS)
                data_highlight = data_highlight.resize((512,512), Image.ANTIALIAS)
                attention_map = Image.fromarray(attention_map)
                attention_map = attention_map.resize((512, 512), Image.ANTIALIAS)
            data_lowlight, data_highlight, attention_map = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0), (np.asarray(attention_map) / 255.0)
            # data_lowlight, data_highlight = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0)
            # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()

            # 将图像rgb转换成Tensor
            if self.normalize:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                transform_input = Compose(
                    [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)), ConvertImageDtype(torch.float), ])
                transform_gt = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                # transform_att = Compose([ToTensor(), ConvertImageDtype(torch.float), ])

                # return transform_input(data_lowlight), transform_gt(data_highlight),transform_att(attention_map)
                return transform_input(data_lowlight), transform_gt(data_highlight)
            else:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                # return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1)
                data_lowlight, data_highlight, attention_map = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float(), torch.from_numpy(attention_map).float()
                return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1), attention_map.permute(2, 0, 1)

    def __len__(self):
        return len(self.data_list)

class att_loader(data.Dataset):

    def __init__(self, images_path, mode='train', normalize=True,size_correct=True):
        self.train_list = populate_train_list(images_path, mode)
        self.mode = mode
        self.data_list = self.train_list
        self.normalize = normalize
        self.size_correct = size_correct
        print("Total examples:", len(self.train_list))


    def __getitem__(self, index):
        data_lowlight_path = self.data_list[index]

        if self.mode == 'train':
            #使用PIL
            data_lowlight = Image.open(data_lowlight_path)  # 打开为RGB格式
            # filename= data_lowlight_path.replace('input', 'gt').split('_')
            # data_highlight = Image.open(filename[0]+'.JPG')
            # data_highlight = Image.open(data_lowlight_path.replace('input', 'gt'))  #lcdp dataset
            # data_att = Image.open(data_lowlight_path.replace('D:/study/code/datasets/lcdp_dataset/input', './ablation/van'))# get pretrained attention map
            # ======== ME 数据集读取
            # filename= data_lowlight_path.replace('input', 'gt').split('-')
            # data_highlight = Image.open(filename[0]+"-"+filename[1]+".jpg")
            filepath = data_lowlight_path.replace('input', 'gt')
            # data_highlight = Image.open(filepath.replace('(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg'))
            data_highlight = Image.open(re.sub(r'(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg', filepath))
            #======== SID 数据集读取
            # filename= data_lowlight_path.replace('inputimage', 'gtimage').split("_00_")
            # data_highlight = Image.open(filename[0]+".png")
            # data_highlight = Image.open(data_lowlight_path.replace('low','normal').replace('Low','Normal').replace('input','expertC_gt'))


            # 获得attentionmap，计算高亮和低亮之间的差异来创建一个注意力图 train_van
            # Get the image buffer as ndarray
            buffer1 = np.asarray(data_lowlight).astype(np.int64)
            buffer2 = np.asarray(data_highlight).astype(np.int64)

            # Subtract data_lowlight from data_highlight
            attention_map = np.clip(buffer2 - buffer1, 0, 255).astype(np.uint8)

            #图像尺寸调整
            if self.size_correct == True:
                data_lowlight = data_lowlight.resize((384,384), Image.ANTIALIAS)
                data_highlight = data_highlight.resize((384,384), Image.ANTIALIAS)
                attention_map = Image.fromarray(attention_map)
                attention_map = attention_map.resize((384,384),Image.ANTIALIAS)

            # train_van
            data_lowlight, data_highlight,attention_map = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0), (np.asarray(attention_map) / 255.0)
            # data_lowlight, data_highlight = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0)

            #正则化
            if self.normalize:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                transform_input = Compose(
                    [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)), ConvertImageDtype(torch.float), ])
                transform_gt = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                transform_att = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                # return transform_input(data_lowlight).permute(2, 0, 1), transform_gt(data_highlight).permute(2, 0, 1)
                return transform_input(data_lowlight), transform_gt(data_highlight),transform_att(attention_map)
            else:
                data_lowlight, data_highlight,attention_map = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float(), torch.from_numpy(attention_map).float()
                return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1), attention_map.permute(2, 0, 1)
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                # return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1)


        elif self.mode == 'test':
            data_lowlight = Image.open(data_lowlight_path)
            # data_highlight = Image.open(data_lowlight_path.replace('/teval','/teval/gt'))#测试用
            data_highlight = Image.open(data_lowlight_path)
            # data_highlight = Image.open(data_lowlight_path.replace('test', 'expertC_gt_test'))
            # data_highlight = Image.open(data_lowlight_path.replace('test', 'test_gt'))#5k_512pix
            # data_highlight = Image.open(data_lowlight_path.replace('low0', 'normal0').replace('Low','Normal')) #LOLv2
            # data_highlight = Image.open(data_lowlight_path.replace('Low', 'High').replace('low', 'high'))  #LOL
            # data_highlight = Image.open(data_lowlight_path.replace('test-input', 'test-gt'))  #lcdp
            # filename = data_lowlight_path.split("\\")[-1]
            # filename = data_lowlight_path.replace('input', 'expert_c_testing_set').split("-")# ME
            # filepath = data_lowlight_path.replace('input', 'expert_c_testing_set')
            # data_highlight = Image.open(filepath.replace(r'(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg'))
            # data_highlight = Image.open(re.sub(r'(_P1\.5|_0|_P1|_N1|_N1\.5)\.JPG$', '.jpg', filepath))

            # data_highlight = Image.open(filename[0] + '_' + filename[1] + ".jpg") # ME
            # data_highlight = Image.open(data_lowlight_path.replace('INPUT_IMAGES', 'expert_c_testing_set'))  # ME
            # ======== SID 数据集读取
            # filename = data_lowlight_path.replace('inputimage', 'gtimage').split("_")
            # data_highlight = Image.open(filename[0] + ".png")

            # 获得attentionmap
            # Get the image buffer as ndarray
            buffer1 = np.asarray(data_lowlight).astype(np.int64)
            buffer2 = np.asarray(data_highlight).astype(np.int64)

            # Subtract data_lowlight from data_highlight

            attention_map = np.clip(buffer2 - buffer1, 0, 255).astype(np.uint8)

            if self.size_correct == True:
                data_lowlight = data_lowlight.resize((384,384), Image.ANTIALIAS)
                data_highlight = data_highlight.resize((384,384), Image.ANTIALIAS)
                attention_map = Image.fromarray(attention_map)
                attention_map = attention_map.resize((384, 384), Image.ANTIALIAS)
            data_lowlight, data_highlight, attention_map = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0), (np.asarray(attention_map) / 255.0)
            # data_lowlight, data_highlight = (np.asarray(data_lowlight) / 255.0), (np.asarray(data_highlight) / 255.0)
            # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()

            # 将图像rgb转换成Tensor
            if self.normalize:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                transform_input = Compose(
                    [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)), ConvertImageDtype(torch.float), ])
                transform_gt = Compose([ToTensor(), ConvertImageDtype(torch.float), ])
                transform_att = Compose([ToTensor(), ConvertImageDtype(torch.float), ])

                return transform_input(data_lowlight), transform_gt(data_highlight),transform_att(attention_map)
                # return transform_input(data_lowlight), transform_gt(data_highlight)
            else:
                # data_lowlight, data_highlight = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float()
                # return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1)
                data_lowlight, data_highlight, attention_map = torch.from_numpy(data_lowlight).float(), torch.from_numpy(data_highlight).float(), torch.from_numpy(attention_map).float()
            return data_lowlight.permute(2, 0, 1), data_highlight.permute(2, 0, 1), attention_map.permute(2, 0, 1), filename

    def __len__(self):
        return len(self.data_list)


import argparse

def load_init(config):
    os.environ['CUDA_VISIBLE_DEVICES'] = str(config.gpu_id)
    parser = argparse.ArgumentParser(description='PyTorch Low-Light Enhancement')
    parser.add_argument('--normalize', default=False)
    parser.add_argument('--resize', default=False)
    opt = parser.parse_args()
    print(opt)

    # Data Setting
    train_dataset = lowlight_loader(images_path=config.train_LL_folder, normalize=opt.normalize,mode="train",size_correct = config.resize)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True, num_workers=1,
                                             pin_memory=True)
    val_dataset = lowlight_loader(images_path=config.img_val_path, normalize=opt.normalize,mode="test",size_correct = config.resize)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=1, shuffle=False, num_workers=1,
                                               pin_memory=True)
    return train_loader,val_loader

def load_init_att(config):
    os.environ['CUDA_VISIBLE_DEVICES'] = str(config.gpu_id)
    parser = argparse.ArgumentParser(description='PyTorch Low-Light Enhancement')
    parser.add_argument('--normalize', default=False)
    parser.add_argument('--resize', default=False)
    opt = parser.parse_args()
    print(opt)

    # Data Setting
    train_dataset = att_loader(images_path=config.train_LL_folder, normalize=opt.normalize,mode="train",size_correct = config.resize)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True, num_workers=1,
                                             pin_memory=True)
    val_dataset = att_loader(images_path=config.img_val_path, normalize=opt.normalize,mode="test",size_correct = config.resize)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=1, shuffle=False, num_workers=1,
                                               pin_memory=True)
    return train_loader,val_loader

def load_init_test():
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    parser = argparse.ArgumentParser(description='PyTorch Low-Light Enhancement')
    # parser.add_argument('--test_LL_folder', default="/mnt/dataset/LLIE/SICE/SICEV2/test/low/")
    # parser.add_argument('--test_LL_folder', default="D:\study\code\datasets\SICEV2/test\input")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/LOL/eval15/Low")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/LOL_v2/Test/Low")
    parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/lcdp_dataset/test-input")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/ME/testing/INPUT_IMAGES")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/BrighteningTrain1000/low")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/DICM")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/LIME")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/NPE")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/VV")
    # parser.add_argument('--test_LL_folder', default="/mnt/dataset/LLIE/MSEC/testing/input")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/fivek/test/")
    # parser.add_argument('--test_LL_folder', default="D:\study\code\datasets\lcdp_dataset/test\i")
    # parser.add_argument('--test_NL_folder', default="D:/study/code/datasets/fivek/expertC_gt_test")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/datasets/ht")
    # parser.add_argument('--test_LL_folder', default="D:/study/code/lab2/data/teval/")
    parser.add_argument('--batch_size', default=1)
    # parser.add_argument('--size_correct', default=False)# LOL
    parser.add_argument('--size_correct', default=True)# others
    parser.add_argument('--normalize', default=False)
    # parser.add_argument('--test_LL_folder', default="/root/autodl-tmp/input")
    # parser.add_argument('--test_NL_folder', default="/root/autodl-tmp/gt")
    # parser.add_argument('--test_est_folder', default="D:/study/code/datasets/LOL_v2/LOL_v2/Test/result_epochbest")

    config = parser.parse_args()

    # Data Setting
    test_dataset = lowlight_loader(images_path=config.test_LL_folder, normalize=config.normalize,mode='test',size_correct = config.size_correct)#测试返回的第三个参数为文件名
    dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=config.batch_size, shuffle=False, num_workers=1,
                                               pin_memory=True)
    return dataloader


if __name__ == '__main__':
    # load_init()
    #======测试读图像两种方法的差异
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    parser = argparse.ArgumentParser(description='PyTorch Low-Light Enhancement')
    parser.add_argument('--test_NL_folder', default="../datasets/fivek/expertC_gt_test")
    opt = parser.parse_args()
    # test_img(opt)
    # resize_pic(opt)


    #======测试灰度图/光照图读取